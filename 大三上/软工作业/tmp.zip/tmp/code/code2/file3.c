int main()
{//666
    return 0;  
}  // gg